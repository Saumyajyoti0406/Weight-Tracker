/* ═══════════════════════════════════════════════
   INSIGHTS MODULE
═══════════════════════════════════════════════ */

// ── Log reminder ──────────────────────────────────────────────────────────────
function checkLogReminder(){
  var td=todayStr();
  var loggedToday=entries.some(function(e){return e.date===td;});
  var banner=document.getElementById('logReminderBanner');
  if(!banner)return;
  if(!loggedToday&&entries.length>0){
    banner.classList.remove('hidden');
  } else {
    banner.classList.add('hidden');
  }
}
function dismissReminder(){
  var banner=document.getElementById('logReminderBanner');
  if(banner) banner.classList.add('hidden');
}
function quickLogToday(){
  // Switch to main log area and focus weight input
  var tabBtn=document.getElementById('tabBtnCharts');
  if(tabBtn) switchTab('charts',tabBtn);
  setTimeout(function(){
    var wi=document.getElementById('weightInput');
    if(wi){wi.focus();wi.scrollIntoView({behavior:'smooth',block:'center'});}
  },200);
  dismissReminder();
}

// ── Streak counter ────────────────────────────────────────────────────────────
function calcStreak(){
  if(!entries.length) return {current:0,best:0};
  var sorted=entries.slice().sort(function(a,b){return b.date.localeCompare(a.date);});
  var current=0, best=0, streak=0;
  var prev=null;
  // Walk backwards from today
  var td=todayStr();
  var checkDate=td;
  for(var i=0;i<sorted.length;i++){
    if(sorted[i].date===checkDate){
      streak++;
      // Move check date back 1 day
      var d=new Date(checkDate+'T00:00:00');
      d.setDate(d.getDate()-1);
      checkDate=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
    } else if(sorted[i].date<checkDate){
      break;
    }
  }
  current=streak;
  // Calculate best streak ever
  var dates=entries.map(function(e){return e.date;}).sort();
  var s=1,b=1;
  for(var i=1;i<dates.length;i++){
    var prev=new Date(dates[i-1]+'T00:00:00');
    var curr=new Date(dates[i]+'T00:00:00');
    var diff=(curr-prev)/(1000*60*60*24);
    if(diff===1){s++;if(s>b)b=s;}
    else{s=1;}
  }
  best=Math.max(b,current);
  return{current:current,best:best};
}

// ── Weekly report card ────────────────────────────────────────────────────────
function calcReportCard(){
  if(entries.length<3) return{grade:'—',logged:0,possible:0,trend:'—',consistency:0};
  // Last 4 weeks
  var now=new Date();
  var fourWeeksAgo=new Date(now); fourWeeksAgo.setDate(now.getDate()-28);
  var start=fourWeeksAgo.toISOString().split('T')[0];
  var recent=entries.filter(function(e){return e.date>=start;});
  // Count how many of last 28 days were logged
  var logged=recent.length;
  var possible=28;
  var pct=logged/possible;
  // Grade
  var grade;
  if(pct>=0.9)grade='A';
  else if(pct>=0.75)grade='B';
  else if(pct>=0.5)grade='C';
  else if(pct>=0.3)grade='D';
  else grade='F';
  // Trend in last 2 weeks
  var twoWeeksAgo=new Date(now); twoWeeksAgo.setDate(now.getDate()-14);
  var tStart=twoWeeksAgo.toISOString().split('T')[0];
  var tEntries=entries.filter(function(e){return e.date>=tStart;});
  var trend='—';
  if(tEntries.length>=2){
    var diff=tEntries[tEntries.length-1].weight-tEntries[0].weight;
    trend=(diff>=0?'+':'')+diff.toFixed(1)+' kg';
  }
  return{grade:grade,logged:logged,possible:possible,trend:trend,consistency:Math.round(pct*100)};
}

// ── Weight loss rate ──────────────────────────────────────────────────────────
function calcLossRate(){
  if(entries.length<7) return null;
  // Last 4 weeks for rate
  var now=new Date();
  var ago=new Date(now); ago.setDate(now.getDate()-28);
  var start=ago.toISOString().split('T')[0];
  var recent=entries.filter(function(e){return e.date>=start;});
  if(recent.length<2) return null;
  var totalChange=recent[recent.length-1].weight-recent[0].weight;
  var days=(new Date(recent[recent.length-1].date)-new Date(recent[0].date))/(1000*60*60*24);
  if(days<1) return null;
  var perWeek=totalChange/(days/7);
  return perWeek;
}

// ── Predicted goal date ───────────────────────────────────────────────────────
function calcPrediction(){
  var p=getProfile();
  if(!p.goal||!entries.length) return null;
  var rate=calcLossRate();
  if(!rate||rate>=0) return null; // not losing
  var latest=entries[entries.length-1].weight;
  var remaining=latest-p.goal;
  if(remaining<=0) return 'Already reached!';
  var weeksNeeded=remaining/Math.abs(rate);
  var predictedDate=new Date();
  predictedDate.setDate(predictedDate.getDate()+Math.round(weeksNeeded*7));
  return predictedDate.getDate()+' '+['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][predictedDate.getMonth()]+' '+predictedDate.getFullYear();
}

// ── Personal best ─────────────────────────────────────────────────────────────
function calcPersonalBest(){
  if(!entries.length) return null;
  var weights=entries.map(function(e){return e.weight;});
  var min=Math.min.apply(null,weights);
  var minEntry=entries.find(function(e){return e.weight===min;});
  return{weight:min,date:minEntry?minEntry.date:''};
}

// ── Milestones ────────────────────────────────────────────────────────────────
var MILESTONES=[
  {id:'first_log',   icon:'🎯', label:'First Log',       check:function(e){return e.length>=1;}},
  {id:'week_streak', icon:'🔥', label:'7 Day Streak',    check:function(e){return calcStreak().best>=7;}},
  {id:'lost_1kg',    icon:'⚡', label:'1kg Lost',         check:function(e){return e.length>=2&&e[0].weight-e[e.length-1].weight>=1;}},
  {id:'lost_3kg',    icon:'💪', label:'3kg Lost',         check:function(e){return e.length>=2&&e[0].weight-e[e.length-1].weight>=3;}},
  {id:'lost_5kg',    icon:'🏆', label:'5kg Lost',         check:function(e){return e.length>=2&&e[0].weight-e[e.length-1].weight>=5;}},
  {id:'lost_10kg',   icon:'🥇', label:'10kg Lost',        check:function(e){return e.length>=2&&e[0].weight-e[e.length-1].weight>=10;}},
  {id:'logged_30',   icon:'📅', label:'30 Days Logged',   check:function(e){return e.length>=30;}},
  {id:'logged_100',  icon:'💯', label:'100 Days Logged',  check:function(e){return e.length>=100;}},
  {id:'goal_reached',icon:'🎉', label:'Goal Reached!',    check:function(e){var p=getProfile();return p.goal&&e.length&&e[e.length-1].weight<=p.goal;}},
];

function getMilestones(){
  var earned=lsGet('wt_milestones',{});
  return MILESTONES.map(function(m){
    var wasEarned=!!earned[m.id];
    var isEarned=m.check(entries);
    if(isEarned&&!wasEarned){
      earned[m.id]=todayStr();
      lsSet('wt_milestones',earned);
    }
    return{id:m.id,icon:m.icon,label:m.label,earned:isEarned,date:earned[m.id]||null};
  });
}

// ── Render Insights tab ───────────────────────────────────────────────────────
function renderInsights(){
  if(!document.getElementById('tab-insights')) return;

  checkLogReminder();

  // Streak
  var streak=calcStreak();
  var streakFire=streak.current>=7?'🔥':streak.current>=3?'⚡':'📅';
  document.getElementById('streakNum').textContent=streak.current;
  document.getElementById('streakFire').textContent=streakFire;
  document.getElementById('streakBest').textContent='Best: '+streak.best+' days';

  // Report card
  var report=calcReportCard();
  var gradeEl=document.getElementById('reportGrade');
  gradeEl.textContent=report.grade;
  gradeEl.className='report-grade grade-'+(report.grade==='—'?'C':report.grade);
  document.getElementById('reportLogged').innerHTML='<strong>'+report.logged+'</strong> / '+report.possible+' days logged (last 4 weeks)';
  document.getElementById('reportConsistency').innerHTML='Consistency: <strong>'+report.consistency+'%</strong>';
  document.getElementById('reportTrend').innerHTML='2-week trend: <strong>'+report.trend+'</strong>';

  // Rate + prediction
  var rate=calcLossRate();
  document.getElementById('lossRate').textContent=rate!==null?(rate<0?'':'+')+(rate).toFixed(2)+' kg/wk':'—';
  var pred=calcPrediction();
  document.getElementById('goalPrediction').textContent=pred||'—';

  // Personal best
  var pb=calcPersonalBest();
  if(pb){
    document.getElementById('personalBest').textContent=pb.weight.toFixed(1)+' kg';
    document.getElementById('personalBestDate').textContent=pb.date;
  } else {
    document.getElementById('personalBest').textContent='—';
    document.getElementById('personalBestDate').textContent='';
  }

  // Before / After
  if(entries.length>=2){
    var first=entries[0], last=entries[entries.length-1];
    document.getElementById('baFirstWeight').textContent=first.weight.toFixed(1)+' kg';
    document.getElementById('baFirstDate').textContent=first.date;
    document.getElementById('baLastWeight').textContent=last.weight.toFixed(1)+' kg';
    document.getElementById('baLastDate').textContent=last.date;
    var diff=last.weight-first.weight;
    var changeEl=document.getElementById('baChange');
    changeEl.textContent=(diff>=0?'▲ +':'▼ ')+Math.abs(diff).toFixed(1)+' kg total';
    changeEl.style.color=diff<0?'var(--neg)':'var(--pos)';
  }

  // Milestones
  var milestones=getMilestones();
  var grid=document.getElementById('milestonesGrid');
  grid.innerHTML=milestones.map(function(m){
    return '<div class="milestone'+(m.earned?' earned':'')+'">'
      +'<div class="milestone-icon">'+m.icon+'</div>'
      +'<div class="milestone-label">'+m.label+'</div>'
      +(m.earned&&m.date?'<div class="milestone-date">'+m.date.substr(5)+'</div>':'')
      +'</div>';
  }).join('');
}
