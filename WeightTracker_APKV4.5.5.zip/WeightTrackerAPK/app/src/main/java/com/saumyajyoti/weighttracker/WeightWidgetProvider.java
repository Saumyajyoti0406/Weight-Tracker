package com.saumyajyoti.weighttracker;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.widget.RemoteViews;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class WeightWidgetProvider extends AppWidgetProvider {

    public static final String ACTION_REFRESH      = "com.saumyajyoti.weighttracker.WIDGET_REFRESH";
    public static final String ACTION_REQUEST_SYNC = "com.saumyajyoti.weighttracker.REQUEST_SYNC";

    // ── Theme color definitions ────────────────────────────────────────────────
    // Each theme: {bgDrawable, btnDrawable, accentColor, weightColor, changeColor, mutedColor, btnTextColor}
    private static class ThemeColors {
        int bgDrawable, btnDrawable;
        int accent, weightText, changeDefault, muted, btnText;

        ThemeColors(int bg, int btn, int accent, int weightText, int changeDef, int muted, int btnText) {
            this.bgDrawable    = bg;
            this.btnDrawable   = btn;
            this.accent        = accent;
            this.weightText    = weightText;
            this.changeDefault = changeDef;
            this.muted         = muted;
            this.btnText       = btnText;
        }
    }

    private static ThemeColors getThemeColors(Context ctx, String theme) {
        switch (theme) {
            case "ocean":
                return new ThemeColors(
                    R.drawable.widget_bg_ocean, R.drawable.widget_btn_ocean,
                    0xFF00C8FF, 0xFFE0F4FF, 0xFF00C8FF, 0xFF1A3A4A, 0xFF020D1A);
            case "sakura":
                return new ThemeColors(
                    R.drawable.widget_bg_sakura, R.drawable.widget_btn_sakura,
                    0xFFFF88B0, 0xFFFFE8F0, 0xFFFF88B0, 0xFF3A1525, 0xFF050509);
            case "ember":
                return new ThemeColors(
                    R.drawable.widget_bg_ember, R.drawable.widget_btn_ember,
                    0xFFFF8C00, 0xFFFFF0E0, 0xFFFF8C00, 0xFF3A1500, 0xFF050500);
            case "forest":
                return new ThemeColors(
                    R.drawable.widget_bg_forest, R.drawable.widget_btn_forest,
                    0xFF4CAF50, 0xFFE0F5E0, 0xFF4CAF50, 0xFF122012, 0xFF030A04);
            case "galaxy":
                return new ThemeColors(
                    R.drawable.widget_bg_galaxy, R.drawable.widget_btn_galaxy,
                    0xFFB266FF, 0xFFF0E8FF, 0xFFB266FF, 0xFF1E0A40, 0xFF04010F);
            case "mocha":
                return new ThemeColors(
                    R.drawable.widget_bg_mocha, R.drawable.widget_btn_mocha,
                    0xFFC8874A, 0xFFE8D5B8, 0xFFC8874A, 0xFF2A1800, 0xFF0F0A07);
            case "cyberpunk":
                return new ThemeColors(
                    R.drawable.widget_bg_cyberpunk, R.drawable.widget_btn_cyberpunk,
                    0xFFFF00CC, 0xFFFFEEFF, 0xFFFF00CC, 0xFF1A001A, 0xFF020005);
            case "arctic":
                return new ThemeColors(
                    R.drawable.widget_bg_arctic, R.drawable.widget_btn_arctic,
                    0xFF55CCFF, 0xFFE8F4FF, 0xFF55CCFF, 0xFF1A3A55, 0xFF020C18);
            case "dark":
                return new ThemeColors(
                    R.drawable.widget_bg_dark, R.drawable.widget_btn_dark,
                    0xFFFFFFFF, 0xFFFFFFFF, 0xFFAAAAAA, 0xFF444444, 0xFF111111);
            case "light":
                return new ThemeColors(
                    R.drawable.widget_bg_light, R.drawable.widget_btn_light,
                    0xFF111111, 0xFF111111, 0xFF444444, 0xFF8899AA, 0xFFFFFFFF);
            default: // neon
                return new ThemeColors(
                    R.drawable.widget_bg_neon, R.drawable.widget_btn_neon,
                    0xFF00FFE0, 0xFFFFFFFF, 0xFF7B5CFA, 0xFF1A2A2A, 0xFF050508);
        }
    }

    // ── AppWidgetProvider callbacks ───────────────────────────────────────────

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        // Ask app to push fresh data if it's running
        ctx.sendBroadcast(new Intent(ACTION_REQUEST_SYNC).setPackage(ctx.getPackageName()));
        for (int id : ids) updateWidget(ctx, mgr, id);
    }

    @Override
    public void onReceive(Context ctx, Intent intent) {
        super.onReceive(ctx, intent);
        if (ACTION_REFRESH.equals(intent.getAction())) {
            AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
            int[] ids = mgr.getAppWidgetIds(new ComponentName(ctx, WeightWidgetProvider.class));
            for (int id : ids) updateWidget(ctx, mgr, id);
        }
    }

    // ── Core widget update ────────────────────────────────────────────────────

    public static void updateWidget(Context ctx, AppWidgetManager mgr, int widgetId) {
        RemoteViews views = new RemoteViews(ctx.getPackageName(), R.layout.widget_weight);

        // ── Read data ────────────────────────────────────────────────────────
        float latest   = SharedDataHelper.getLatestWeight(ctx);
        float previous = SharedDataHelper.getPreviousWeight(ctx);
        float goal     = SharedDataHelper.getGoal(ctx);
        int   streak   = SharedDataHelper.getStreak(ctx);
        float progress = SharedDataHelper.getGoalProgress(ctx);
        String name    = SharedDataHelper.getUserName(ctx);
        String theme   = SharedDataHelper.getTheme(ctx);

        // ── Apply theme or transparent mode ──────────────────────────────────
        boolean transparent = SharedDataHelper.getWidgetTransparent(ctx);
        // Declare tc at outer scope so it's accessible throughout the method
        ThemeColors tc = getThemeColors(ctx, theme);

        if (transparent) {
            views.setInt(R.id.widgetRoot,   "setBackgroundResource", R.drawable.widget_bg_transparent);
            views.setInt(R.id.widgetLogBtn, "setBackgroundResource", R.drawable.widget_btn_transparent);
            views.setTextColor(R.id.widgetAppName,   0xCCFFFFFF);
            views.setTextColor(R.id.widgetStreak,    0xFFFFE600);
            views.setTextColor(R.id.widgetWeight,    0xFFFFFFFF);
            views.setTextColor(R.id.widgetChange,    0xDDFFFFFF);
            views.setTextColor(R.id.widgetGoalLabel, 0xAAFFFFFF);
            views.setTextColor(R.id.widgetUpdated,   0x88FFFFFF);
            views.setTextColor(R.id.widgetLogBtn,    0xFFFFFFFF);
        } else {
            views.setInt(R.id.widgetRoot,   "setBackgroundResource", tc.bgDrawable);
            views.setInt(R.id.widgetLogBtn, "setBackgroundResource", tc.btnDrawable);
            views.setTextColor(R.id.widgetAppName,   tc.accent);
            views.setTextColor(R.id.widgetStreak,    tc.accent);
            views.setTextColor(R.id.widgetWeight,    tc.weightText);
            views.setTextColor(R.id.widgetGoalLabel, tc.muted);
            views.setTextColor(R.id.widgetUpdated,   tc.muted);
            views.setTextColor(R.id.widgetLogBtn,    tc.btnText);
        }

        // ── User name ────────────────────────────────────────────────────────
        views.setTextViewText(R.id.widgetAppName,
            name.toUpperCase(Locale.getDefault()));

        // ── Streak ───────────────────────────────────────────────────────────
        String streakLabel = streak >= 7 ? "🔥 " + streak + " days"
                           : streak >= 3 ? "⚡ " + streak + " days"
                           : streak == 1 ? "📅 1 day"
                           : "📅 0 days";
        views.setTextViewText(R.id.widgetStreak, streakLabel);

        // ── Weight ───────────────────────────────────────────────────────────
        views.setTextViewText(R.id.widgetWeight,
            latest > 0
                ? String.format(Locale.getDefault(), "%.1f kg", latest)
                : "-- kg");

        // ── Change from previous ─────────────────────────────────────────────
        if (latest > 0 && previous > 0) {
            float diff = latest - previous;
            String arrow = diff < 0 ? "▼" : diff > 0 ? "▲" : "–";
            views.setTextViewText(R.id.widgetChange,
                String.format(Locale.getDefault(), "%s %.1f kg from last", arrow, Math.abs(diff)));
            int col;
            if (transparent) {
                col = diff < 0 ? 0xFF00FFE0 : diff > 0 ? 0xFFFF4D6D : 0xDDFFFFFF;
            } else {
                col = diff < 0 ? tc.accent : diff > 0 ? 0xFFFF4D6D : tc.changeDefault;
            }
            views.setTextColor(R.id.widgetChange, col);
        } else if (latest > 0) {
            views.setTextViewText(R.id.widgetChange, "First entry logged ✓");
            views.setTextColor(R.id.widgetChange, transparent ? 0xCCFFFFFF : tc.accent);
        } else {
            views.setTextViewText(R.id.widgetChange, "Open app to start logging");
            views.setTextColor(R.id.widgetChange, transparent ? 0x88FFFFFF : tc.muted);
        }

        // ── Goal ─────────────────────────────────────────────────────────────
        if (goal > 0 && latest > 0) {
            int pct = progress >= 0 ? Math.round(progress * 100) : 0;
            float remaining = Math.abs(latest - goal);
            views.setTextViewText(R.id.widgetGoalLabel,
                String.format(Locale.getDefault(),
                    "Goal %.1f kg  •  %d%%  •  %.1f to go", goal, pct, remaining));
        } else {
            views.setTextViewText(R.id.widgetGoalLabel, "Set a goal in the app");
        }

        // ── Updated time ─────────────────────────────────────────────────────
        String time = new SimpleDateFormat("h:mm a", Locale.getDefault()).format(new Date());
        views.setTextViewText(R.id.widgetUpdated, "Updated " + time);

        // ── PendingIntent flags ───────────────────────────────────────────────
        int piFlags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
            ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            : PendingIntent.FLAG_UPDATE_CURRENT;

        // Tap body → open app
        Intent openApp = new Intent(ctx, MainActivity.class);
        openApp.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(ctx, 10, openApp, piFlags);
        views.setOnClickPendingIntent(R.id.widgetWeight,    openPi);
        views.setOnClickPendingIntent(R.id.widgetChange,    openPi);
        views.setOnClickPendingIntent(R.id.widgetGoalLabel, openPi);
        views.setOnClickPendingIntent(R.id.widgetUpdated,   openPi);
        views.setOnClickPendingIntent(R.id.widgetAppName,   openPi);
        views.setOnClickPendingIntent(R.id.widgetStreak,    openPi);

        // Tap "+ Log" → open app on log tab
        Intent logIntent = new Intent(ctx, MainActivity.class);
        logIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        logIntent.putExtra("action", "log");
        PendingIntent logPi = PendingIntent.getActivity(ctx, 11, logIntent, piFlags);
        views.setOnClickPendingIntent(R.id.widgetLogBtn, logPi);

        mgr.updateAppWidget(widgetId, views);
    }

    /** Call whenever data changes — refreshes all widget instances. */
    public static void notifyDataChanged(Context ctx) {
        Intent intent = new Intent(ctx, WeightWidgetProvider.class);
        intent.setAction(ACTION_REFRESH);
        ctx.sendBroadcast(intent);
    }
}
