package com.saumyajyoti.weighttracker;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.Manifest;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private WebView webView;

    // ── File chooser (for import) ────────────────────────────────────────────
    private ValueCallback<Uri[]>  filePathCallback;
    private static final int      FILE_CHOOSER_CODE    = 100;

    // ── Export (save to Downloads) ───────────────────────────────────────────
    private static final int      STORAGE_PERM_CODE    = 101;
    private String                pendingExportData    = null;
    private String                pendingExportName    = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        );
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(Color.parseColor("#050508"));
            getWindow().setNavigationBarColor(Color.parseColor("#050508"));
        }
        if (Build.VERSION.SDK_INT >= 19) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        webView = new WebView(this);
        setupWebView();
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    // ── WebView setup ────────────────────────────────────────────────────────
    private void setupWebView() {
        webView.setBackgroundColor(Color.parseColor("#050508"));
        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        if (Build.VERSION.SDK_INT >= 21) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        webView.addJavascriptInterface(new AppBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) { return false; }
        });

        // ── This is the critical part — override file chooser ────────────────
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams) {

                // Cancel any previous callback
                if (MainActivity.this.filePathCallback != null) {
                    MainActivity.this.filePathCallback.onReceiveValue(null);
                }
                MainActivity.this.filePathCallback = filePathCallback;

                // Build intent to pick CSV / Excel files
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                // Accept CSV, Excel, and plain text
                intent.setType("*/*");
                String[] mimeTypes = {
                    "text/csv",
                    "text/comma-separated-values",
                    "text/plain",
                    "application/csv",
                    "application/vnd.ms-excel",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                };
                intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
                intent.putExtra(Intent.EXTRA_TITLE, "Select CSV or Excel file");

                try {
                    startActivityForResult(
                        Intent.createChooser(intent, "Choose file to import"),
                        FILE_CHOOSER_CODE
                    );
                } catch (Exception e) {
                    MainActivity.this.filePathCallback = null;
                    return false;
                }
                return true;
            }
        });
    }

    // ── Handle file picker result ────────────────────────────────────────────
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_CODE) {
            if (filePathCallback == null) return;

            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK && data != null) {
                Uri uri = data.getData();
                if (uri != null) {
                    results = new Uri[]{uri};
                    // Read the file content and pass to JS
                    readFileAndSendToJS(uri);
                }
            }

            // Must call this to un-block the WebView input
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    // ── Read file bytes and pass content to JS ───────────────────────────────
    private void readFileAndSendToJS(Uri uri) {
        new Thread(new Runnable() {
            public void run() {
                try {
                    // Get file name
                    String fileName = getFileNameFromUri(uri);
                    String ext = fileName.contains(".")
                        ? fileName.substring(fileName.lastIndexOf('.') + 1).toLowerCase()
                        : "";

                    InputStream is = getContentResolver().openInputStream(uri);
                    if (is == null) {
                        sendImportError("Could not open the file.");
                        return;
                    }

                    // Read all bytes
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int n;
                    long totalBytes = 0;
                    while ((n = is.read(buf)) != -1) {
                        baos.write(buf, 0, n);
                        totalBytes += n;
                        if (totalBytes > 5 * 1024 * 1024) { // 5MB guard
                            is.close();
                            sendImportError("File is too large (max 5MB).");
                            return;
                        }
                    }
                    is.close();

                    if (ext.equals("xlsx") || ext.equals("xls")) {
                        // For XLSX: send as base64 to JS
                        byte[] bytes = baos.toByteArray();
                        String b64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP);
                        final String safeFileName = fileName.replace("'", "\\'");
                        final String safeB64 = b64;
                        runOnUiThread(new Runnable() {
                            public void run() {
                                webView.evaluateJavascript(
                                    "receiveXLSXData('" + safeFileName + "','" + safeB64 + "')",
                                    null
                                );
                            }
                        });
                    } else {
                        // For CSV/TXT: send as text string
                        String text = baos.toString("UTF-8");
                        // Escape for JS string: backslash, backtick, $ 
                        text = text.replace("\\", "\\\\")
                                   .replace("`", "\\`")
                                   .replace("$", "\\$");
                        final String safeFileName = fileName.replace("'", "\\'");
                        final String safeText = text;
                        runOnUiThread(new Runnable() {
                            public void run() {
                                // Use template literal to avoid quote escaping issues
                                webView.evaluateJavascript(
                                    "receiveCSVData('" + safeFileName + "', `" + safeText + "`)",
                                    null
                                );
                            }
                        });
                    }

                } catch (Exception e) {
                    sendImportError("Error reading file: " + (e.getMessage() != null ? e.getMessage() : "unknown"));
                }
            }
        }).start();
    }

    private void sendImportError(final String msg) {
        runOnUiThread(new Runnable() {
            public void run() {
                String safeMsg = msg.replace("'", "\\'").replace("\n", " ");
                webView.evaluateJavascript("showImportError('" + safeMsg + "')", null);
            }
        });
    }

    private String getFileNameFromUri(Uri uri) {
        String name = "import_file";
        try {
            android.database.Cursor cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) name = cursor.getString(idx);
                cursor.close();
            }
        } catch (Exception e) {
            // fallback: extract from URI path
            String path = uri.getPath();
            if (path != null) {
                name = path.substring(path.lastIndexOf('/') + 1);
            }
        }
        return name;
    }

    // ── JavaScript Bridge (export) ───────────────────────────────────────────
    public class AppBridge {

        @JavascriptInterface
        public void saveExcelFile(String csvData, String fileName) {
            pendingExportData = csvData;
            pendingExportName = fileName;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                doSaveFile(csvData, fileName);
            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                    checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        STORAGE_PERM_CODE
                    );
                } else {
                    doSaveFile(csvData, fileName);
                }
            }
        }
    }

    private void doSaveFile(String csvData, String fileName) {
        try {
            OutputStream out;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                cv.put(MediaStore.Downloads.MIME_TYPE, "text/csv");
                cv.put(MediaStore.Downloads.IS_PENDING, 1);
                Uri col = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
                Uri itemUri = getContentResolver().insert(col, cv);
                out = getContentResolver().openOutputStream(itemUri);
                out.write(csvData.getBytes("UTF-8"));
                out.close();
                cv.clear();
                cv.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(itemUri, cv, null, null);
            } else {
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                dir.mkdirs();
                File file = new File(dir, fileName);
                out = new FileOutputStream(file);
                out.write(csvData.getBytes("UTF-8"));
                out.close();
            }
            final String fn = fileName;
            runOnUiThread(new Runnable() {
                public void run() {
                    webView.evaluateJavascript("onExportSuccess('" + fn.replace("'", "\\'") + "')", null);
                }
            });
        } catch (Exception e) {
            final String err = e.getMessage() != null ? e.getMessage().replace("'", "") : "unknown";
            runOnUiThread(new Runnable() {
                public void run() {
                    webView.evaluateJavascript("onExportFailed('" + err + "')", null);
                }
            });
        }
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] grants) {
        super.onRequestPermissionsResult(req, perms, grants);
        if (req == STORAGE_PERM_CODE && grants.length > 0
                && grants[0] == PackageManager.PERMISSION_GRANTED
                && pendingExportData != null) {
            doSaveFile(pendingExportData, pendingExportName);
            pendingExportData = null;
            pendingExportName = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onPause()  { super.onPause();  webView.onPause();  }
    @Override protected void onResume() { super.onResume(); webView.onResume(); }
}
