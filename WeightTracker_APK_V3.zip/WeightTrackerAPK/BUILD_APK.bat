@echo off
title Weight Tracker APK Builder
color 0B
echo.
echo  ╔══════════════════════════════════════════════╗
echo  ║   Saumyajyoti Weight Tracker — APK Builder   ║
echo  ╚══════════════════════════════════════════════╝
echo.

:: ── Step 1: Download Chart.js into assets ───────────────────────────────────
echo  [1/3] Downloading Chart.js...
python -c "import urllib.request; urllib.request.urlretrieve('https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.js', 'app\\src\\main\\assets\\chart.umd.js'); print('  Done.')"
if errorlevel 1 ( echo ERROR: Download failed. Check internet. & pause & exit /b 1 )

:: ── Step 2: Set SDK path ─────────────────────────────────────────────────────
echo  [2/3] Configuring Android SDK path...
set ANDROID_SDK=%LOCALAPPDATA%\Android\Sdk
if not exist "%ANDROID_SDK%" (
    echo.
    echo  Android SDK not found at: %ANDROID_SDK%
    echo.
    echo  Please install Android Studio from:
    echo  https://developer.android.com/studio
    echo.
    echo  Then run this script again.
    start https://developer.android.com/studio
    pause & exit /b 1
)
echo sdk.dir=%ANDROID_SDK:\=\\%> local.properties
echo  SDK found: %ANDROID_SDK%

:: ── Step 3: Build APK ────────────────────────────────────────────────────────
echo  [3/3] Building APK (~2 minutes first time)...
call gradlew.bat assembleDebug

if errorlevel 1 (
    echo.
    echo  BUILD FAILED. See errors above.
    pause & exit /b 1
)

echo.
echo  ╔══════════════════════════════════════════════════════════╗
echo  ║  APK READY!                                              ║
echo  ║                                                          ║
echo  ║  File: app\build\outputs\apk\debug\app-debug.apk         ║
echo  ║                                                          ║
echo  ║  Install on Android:                                     ║
echo  ║  1. Copy APK to your phone                               ║
echo  ║  2. Enable "Install from unknown sources" in Settings    ║
echo  ║  3. Tap the APK file to install                          ║
echo  ╚══════════════════════════════════════════════════════════╝
echo.
pause
