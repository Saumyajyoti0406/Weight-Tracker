package com.saumyajyoti.weighttracker;

import android.app.Activity;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.Manifest;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {

    private WebView webView;
    private static final int STORAGE_PERMISSION_CODE = 101;
    private String pendingExportData = null;
    private String pendingExportName = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(Color.parseColor("#050508"));
            getWindow().setNavigationBarColor(Color.parseColor("#050508"));
        }
        if (Build.VERSION.SDK_INT >= 19) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        webView = new WebView(this);
        setupWebView();
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void setupWebView() {
        webView.setBackgroundColor(Color.parseColor("#050508"));
        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        if (Build.VERSION.SDK_INT >= 21) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        webView.addJavascriptInterface(new AppBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) { return false; }
        });
        webView.setWebChromeClient(new WebChromeClient());
    }

    // ── JavaScript Bridge ────────────────────────────────────────────────────
    public class AppBridge {

        // Called from JS with the full CSV string and desired filename
        @JavascriptInterface
        public void saveExcelFile(String csvData, String fileName) {
            pendingExportData = csvData;
            pendingExportName = fileName;

            // Android 10+ uses MediaStore — no permission needed
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                doSaveFile(csvData, fileName);
            } else {
                // Android 9 and below — need WRITE_EXTERNAL_STORAGE permission
                if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        == PackageManager.PERMISSION_GRANTED) {
                    doSaveFile(csvData, fileName);
                } else {
                    requestPermissions(
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        STORAGE_PERMISSION_CODE
                    );
                }
            }
        }
    }

    private void doSaveFile(String csvData, String fileName) {
        try {
            OutputStream outputStream;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Android 10+ — use MediaStore to save to Downloads
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                values.put(MediaStore.Downloads.MIME_TYPE, "text/csv");
                values.put(MediaStore.Downloads.IS_PENDING, 1);

                Uri collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
                Uri itemUri = getContentResolver().insert(collection, values);

                outputStream = getContentResolver().openOutputStream(itemUri);
                outputStream.write(csvData.getBytes("UTF-8"));
                outputStream.close();

                values.clear();
                values.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(itemUri, values, null, null);

            } else {
                // Android 9 and below — write directly to Downloads folder
                File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                downloadsDir.mkdirs();
                File file = new File(downloadsDir, fileName);
                outputStream = new FileOutputStream(file);
                outputStream.write(csvData.getBytes("UTF-8"));
                outputStream.close();
            }

            // Tell JS it worked
            final String fn = fileName;
            runOnUiThread(new Runnable() {
                public void run() {
                    webView.evaluateJavascript("onExportSuccess('" + fn + "')", null);
                }
            });

        } catch (Exception e) {
            final String err = e.getMessage();
            runOnUiThread(new Runnable() {
                public void run() {
                    webView.evaluateJavascript("onExportFailed('" + (err != null ? err.replace("'", "") : "unknown error") + "')", null);
                }
            });
        }
    }

    // Handle permission result for Android 9 and below
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (pendingExportData != null) {
                    doSaveFile(pendingExportData, pendingExportName);
                    pendingExportData = null;
                    pendingExportName = null;
                }
            } else {
                runOnUiThread(new Runnable() {
                    public void run() {
                        webView.evaluateJavascript("onExportFailed('Storage permission denied')", null);
                    }
                });
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onPause() { super.onPause(); webView.onPause(); }
    @Override protected void onResume() { super.onResume(); webView.onResume(); }
}
