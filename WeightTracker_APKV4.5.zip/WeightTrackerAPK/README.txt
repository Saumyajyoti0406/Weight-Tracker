━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Saumyajyoti Weight Tracker — Android APK
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

HOW TO BUILD THE APK (2 steps only)
─────────────────────────────────────

STEP 1 — Install Android Studio (one time only):
  → https://developer.android.com/studio
  Just install it, you don't need to open it.
  It installs the Android SDK automatically.

STEP 2 — Double-click BUILD_APK.bat
  It will:
  • Detect your Android SDK automatically
  • Download Chart.js (needs internet once)
  • Build the APK (~2 min first time, ~20s after)
  • Tell you exactly where the APK file is

STEP 3 — Install on your phone:
  • Copy the APK file to your Android phone
  • On your phone: Settings → Security →
    Enable "Install from unknown sources"
  • Tap the APK file → Install


WHERE IS THE APK?
──────────────────
  app\build\outputs\apk\debug\app-debug.apk


DATA STORAGE
─────────────
Your weight data saves in the app's private
storage on your Android device automatically.
Survives app restarts. Lost only if you
uninstall the app.


FEATURES
─────────
  ✓ Full neon geometric animated background
  ✓ Log weight — today or past only
  ✓ Future dates locked
  ✓ Monthly chart with navigation
  ✓ Month history pills
  ✓ Stats: current, start, total change
  ✓ Runs fully offline
  ✓ Portrait mode, full screen
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
