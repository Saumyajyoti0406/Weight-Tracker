/* ═══════════════════════════════════════════════
   NUTRITION MODULE
   Calories + water intake per day
═══════════════════════════════════════════════ */

var nutritionChart=null;

function loadNutrition(){ return lsGet('wt_nutrition',[]); }
function saveNutrition(data){ lsSet('wt_nutrition',data); }
function getNutritionGoals(){ return lsGet('wt_nutrition_goals',{calories:2000,water:2.5}); }
function saveNutritionGoals(g){ lsSet('wt_nutrition_goals',g); }

function addNutrition(){
  var date=document.getElementById('nutriDate').value;
  if(!date){showToast('pick a date','err');return;}
  if(date>todayStr()){showToast('future dates locked!','err');return;}

  var calories=parseInt(document.getElementById('nutriCal').value)||null;
  var water   =parseFloat(document.getElementById('nutriWater').value)||null;

  if(!calories&&!water){showToast('enter calories or water','err');return;}
  if(calories&&(calories<0||calories>10000)){showToast('calories out of range (0-10000)','err');return;}
  if(water&&(water<0||water>20)){showToast('water out of range (0-20L)','err');return;}

  var data=loadNutrition();
  var idx=data.findIndex(function(r){return r.date===date;});
  var entry={date:date,calories:calories,water:water};

  if(idx>=0){
    // Merge — keep existing values if new ones not provided
    if(!calories&&data[idx].calories) entry.calories=data[idx].calories;
    if(!water&&data[idx].water)       entry.water=data[idx].water;
    data[idx]=entry;
    showToast('updated!');
  } else {
    data.push(entry);
    data.sort(function(a,b){return a.date.localeCompare(b.date);});
    showToast('logged!');
  }

  saveNutrition(data);
  document.getElementById('nutriCal').value='';
  document.getElementById('nutriWater').value='';
  renderNutrition();
}

function deleteNutrition(date){
  var data=loadNutrition().filter(function(r){return r.date!==date;});
  saveNutrition(data);
  renderNutrition();
  showToast('deleted');
}

function saveNutritionGoalsUI(){
  var cal=parseInt(document.getElementById('goalCal').value)||2000;
  var water=parseFloat(document.getElementById('goalWater').value)||2.5;
  saveNutritionGoals({calories:Math.max(500,Math.min(10000,cal)),water:Math.max(0.5,Math.min(20,water))});
  renderNutrition();
  showToast('goals updated!');
}

function renderNutrition(){
  var data=loadNutrition();
  var goals=getNutritionGoals();
  var td=todayStr();

  // Set goal inputs
  document.getElementById('goalCal').value=goals.calories;
  document.getElementById('goalWater').value=goals.water;

  // Today's values
  var todayEntry=data.find(function(r){return r.date===td;});
  var todayCal=todayEntry&&todayEntry.calories?todayEntry.calories:0;
  var todayWater=todayEntry&&todayEntry.water?todayEntry.water:0;

  document.getElementById('todayCal').textContent=todayCal?todayCal.toLocaleString():'—';
  document.getElementById('todayWater').textContent=todayWater?todayWater.toFixed(1)+'L':'—';

  // Goal bars
  var calPct=goals.calories?Math.min(100,Math.round(todayCal/goals.calories*100)):0;
  var waterPct=goals.water?Math.min(100,Math.round(todayWater/goals.water*100)):0;
  document.getElementById('calGoalBar').style.width=calPct+'%';
  document.getElementById('waterGoalBar').style.width=waterPct+'%';
  document.getElementById('calGoalPct').textContent=calPct+'% of '+goals.calories.toLocaleString()+' kcal goal';
  document.getElementById('waterGoalPct').textContent=waterPct+'% of '+goals.water+'L goal';

  // Chart — last 14 days
  var now=new Date();
  var ago=new Date(now); ago.setDate(now.getDate()-13);
  var startDate=ago.getFullYear()+'-'+String(ago.getMonth()+1).padStart(2,'0')+'-'+String(ago.getDate()).padStart(2,'0');
  var recent=data.filter(function(r){return r.date>=startDate;});

  var cv2=document.getElementById('nutritionChart');
  if(recent.length>=2){
    var labels=recent.map(function(r){var d=new Date(r.date+'T00:00:00');return d.getDate()+'/'+String(d.getMonth()+1);});
    var calData=recent.map(function(r){return r.calories||null;});
    var waterData=recent.map(function(r){return r.water?r.water*100:null;}); // scale for dual axis

    if(nutritionChart){nutritionChart.destroy();nutritionChart=null;}
    nutritionChart=new Chart(cv2,{type:'bar',
      data:{labels:labels,datasets:[
        {label:'Calories',data:calData,backgroundColor:'rgba(255,152,0,0.5)',borderColor:'#ff9800',borderWidth:1,borderRadius:4,yAxisID:'yCal'},
        {label:'Water (x100ml)',data:waterData,backgroundColor:'rgba(0,180,255,0.4)',borderColor:'#00b4ff',borderWidth:1,borderRadius:4,yAxisID:'yCal'}
      ]},
      options:{responsive:true,maintainAspectRatio:false,animation:{duration:200},
        plugins:{legend:{display:true,labels:{color:getComputedStyle(document.body).getPropertyValue('--chart-tick').trim(),font:{size:9},boxWidth:10}}},
        scales:{
          yCal:{grid:{color:'rgba(255,255,255,0.04)'},ticks:{color:getComputedStyle(document.body).getPropertyValue('--chart-tick').trim(),font:{size:8}},border:{color:'rgba(255,255,255,0.06)'}},
          x:{grid:{display:false},ticks:{color:getComputedStyle(document.body).getPropertyValue('--chart-tick').trim(),font:{size:8}},border:{color:'rgba(255,255,255,0.06)'}}
        }}});
  } else {
    if(nutritionChart){nutritionChart.destroy();nutritionChart=null;}
  }

  // Log list
  var list=document.getElementById('nutritionLogList');
  var sorted=data.slice().sort(function(a,b){return b.date.localeCompare(a.date);}).slice(0,20);
  if(!sorted.length){
    list.innerHTML='<div style="text-align:center;padding:16px;font-family:var(--font-mono);font-size:10px;color:var(--text4);">No nutrition data yet</div>';
    return;
  }
  list.innerHTML=sorted.map(function(r){
    var d=new Date(r.date+'T00:00:00'),isToday=r.date===td;
    return '<div class="nutrition-log-row">'
      +'<span class="nl-date">'+d.getDate()+' '+MN[d.getMonth()]+' '+d.getFullYear()+(isToday?' <span style="color:var(--accent);font-size:8px;">TODAY</span>':'')+'</span>'
      +'<span class="nl-cal">'+(r.calories?'🔥 '+r.calories.toLocaleString():'🔥 —')+'</span>'
      +'<span class="nl-water">'+(r.water?'💧 '+r.water.toFixed(1)+'L':'💧 —')+'</span>'
      +'<button class="nl-del" onclick="deleteNutrition(\''+r.date+'\')">✕</button>'
      +'</div>';
  }).join('');
}
