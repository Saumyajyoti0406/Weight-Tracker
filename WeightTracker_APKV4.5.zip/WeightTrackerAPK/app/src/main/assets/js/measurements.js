/* ═══════════════════════════════════════════════
   MEASUREMENTS MODULE
   Tracks waist, chest, arms, hips over time
═══════════════════════════════════════════════ */

var measureCharts={};

function loadMeasurements(){ return lsGet('wt_measurements',[]); }
function saveMeasurements(data){ lsSet('wt_measurements',data); }

function addMeasurement(){
  var date=document.getElementById('measureDate').value;
  if(!date){showToast('pick a date','err');return;}
  if(date>todayStr()){showToast('future dates locked!','err');return;}

  var waist =parseFloat(document.getElementById('mWaist').value)||null;
  var chest =parseFloat(document.getElementById('mChest').value)||null;
  var arms  =parseFloat(document.getElementById('mArms').value)||null;
  var hips  =parseFloat(document.getElementById('mHips').value)||null;

  if(!waist&&!chest&&!arms&&!hips){
    showToast('enter at least one measurement','err');return;
  }

  // Validate ranges (in cm)
  if(waist&&(waist<40||waist>200)){showToast('waist out of range (40-200cm)','err');return;}
  if(chest&&(chest<40||chest>200)){showToast('chest out of range (40-200cm)','err');return;}
  if(arms&&(arms<10||arms>100)) {showToast('arms out of range (10-100cm)','err');return;}
  if(hips&&(hips<40||hips>200)) {showToast('hips out of range (40-200cm)','err');return;}

  var data=loadMeasurements();
  var idx=data.findIndex(function(r){return r.date===date;});
  var entry={date:date,waist:waist,chest:chest,arms:arms,hips:hips};

  if(idx>=0){data[idx]=entry;showToast('measurements updated!');}
  else{data.push(entry);data.sort(function(a,b){return a.date.localeCompare(b.date);});showToast('saved!');}

  saveMeasurements(data);
  // Clear inputs
  ['mWaist','mChest','mArms','mHips'].forEach(function(id){document.getElementById(id).value='';});
  renderMeasurements();
}

function deleteMeasurement(date){
  var data=loadMeasurements().filter(function(r){return r.date!==date;});
  saveMeasurements(data);
  renderMeasurements();
  showToast('deleted');
}

function renderMeasurementChart(canvasId, data, key, color, label){
  var pts=data.filter(function(r){return r[key]!==null&&r[key]!==undefined;});
  var nd=document.getElementById('noData_'+canvasId);
  var cv=document.getElementById(canvasId);
  if(!pts.length){
    if(nd)nd.style.display='flex';
    if(cv)cv.style.display='none';
    if(measureCharts[canvasId]){measureCharts[canvasId].destroy();delete measureCharts[canvasId];}
    return;
  }
  if(nd)nd.style.display='none';
  if(cv)cv.style.display='block';
  var labels=pts.map(function(r){var d=new Date(r.date+'T00:00:00');return d.getDate()+' '+MN[d.getMonth()];});
  var vals=pts.map(function(r){return r[key];});
  var minV=Math.min.apply(null,vals)-2, maxV=Math.max.apply(null,vals)+2;
  if(measureCharts[canvasId]){measureCharts[canvasId].destroy();}
  measureCharts[canvasId]=new Chart(cv,{type:'line',
    data:{labels:labels,datasets:[{label:label,data:vals,borderColor:color,
      backgroundColor:'rgba(0,0,0,0.05)',
      borderWidth:2,pointBackgroundColor:color,pointBorderColor:cv_('--bg'),
      pointRadius:3,pointHoverRadius:5,fill:true,tension:0.35}]},
    options:{responsive:true,maintainAspectRatio:false,animation:{duration:200},
      plugins:{legend:{display:false},tooltip:{backgroundColor:'rgba(0,0,0,0.85)',
        titleColor:'#aaa',bodyColor:color,
        callbacks:{label:function(c){return ' '+c.parsed.y.toFixed(1)+' cm';}}}},
      scales:{x:{grid:{color:cv_('--chart-grid')},ticks:{color:cv_('--chart-tick'),font:{size:8},maxRotation:45,autoSkip:true,maxTicksLimit:6},border:{color:cv_('--chart-b')}},
        y:{min:Math.floor(minV),max:Math.ceil(maxV),grid:{color:cv_('--chart-grid')},
          ticks:{color:cv_('--chart-tick'),font:{size:8},callback:function(v){return v.toFixed(0);}},
          border:{color:cv_('--chart-b')}}}}});
}

function cv_(name){return getComputedStyle(document.body).getPropertyValue(name).trim();}

function renderMeasurements(){
  var data=loadMeasurements();

  // Latest values
  var latestWaist=null,latestChest=null,latestArms=null,latestHips=null;
  data.forEach(function(r){
    if(r.waist)latestWaist=r.waist;
    if(r.chest)latestChest=r.chest;
    if(r.arms)latestArms=r.arms;
    if(r.hips)latestHips=r.hips;
  });
  document.getElementById('latestWaist').textContent=latestWaist?latestWaist.toFixed(1)+' cm':'—';
  document.getElementById('latestChest').textContent=latestChest?latestChest.toFixed(1)+' cm':'—';
  document.getElementById('latestArms').textContent=latestArms?latestArms.toFixed(1)+' cm':'—';
  document.getElementById('latestHips').textContent=latestHips?latestHips.toFixed(1)+' cm':'—';

  // Charts
  renderMeasurementChart('chartWaist', data, 'waist', '#00ffe0', 'Waist');
  renderMeasurementChart('chartChest', data, 'chest', '#7b5cfa', 'Chest');
  renderMeasurementChart('chartArms',  data, 'arms',  '#ff4d6d', 'Arms');
  renderMeasurementChart('chartHips',  data, 'hips',  '#ffe600', 'Hips');

  // Log list
  var list=document.getElementById('measureLogList');
  var sorted=data.slice().sort(function(a,b){return b.date.localeCompare(a.date);}).slice(0,20);
  if(!sorted.length){
    list.innerHTML='<div style="text-align:center;padding:16px;font-family:var(--font-mono);font-size:10px;color:var(--text4);">No measurements yet</div>';
    return;
  }
  list.innerHTML=sorted.map(function(r){
    var d=new Date(r.date+'T00:00:00');
    return '<div class="measure-log-row">'
      +'<span class="measure-log-date">'+d.getDate()+' '+MN[d.getMonth()]+' '+d.getFullYear()+'</span>'
      +'<div class="measure-log-vals">'
      +(r.waist?'<div class="measure-log-val">'+r.waist.toFixed(1)+'<span>Waist</span></div>':'')
      +(r.chest?'<div class="measure-log-val">'+r.chest.toFixed(1)+'<span>Chest</span></div>':'')
      +(r.arms ?'<div class="measure-log-val">'+r.arms.toFixed(1)+'<span>Arms</span></div>':'')
      +(r.hips ?'<div class="measure-log-val">'+r.hips.toFixed(1)+'<span>Hips</span></div>':'')
      +'</div>'
      +'<button class="del-btn" onclick="deleteMeasurement(\''+r.date+'\')">✕</button>'
      +'</div>';
  }).join('');
}
