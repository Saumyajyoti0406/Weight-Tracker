package com.saumyajyoti.weighttracker;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.Manifest;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private WebView webView;

    // ── Request codes ─────────────────────────────────────────────────────────
    private static final int REQ_IMPORT_FILE   = 100;
    private static final int REQ_RESTORE_FILE  = 102;
    private static final int REQ_STORAGE_PERM  = 101;
    private static final int REQ_NOTIF_PERM    = 200;

    private ValueCallback<Uri[]> importFileCallback = null;
    private String pendingData = null, pendingFileName = null, pendingMime = null;

    // ── Widget sync receiver — listens while app is in foreground ─────────────
    private BroadcastReceiver syncReceiver = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(Color.parseColor("#050508"));
            getWindow().setNavigationBarColor(Color.parseColor("#050508"));
        }
        if (Build.VERSION.SDK_INT >= 19) WebView.setWebContentsDebuggingEnabled(true);

        // ── Notification permission (Android 13+) ────────────────────────────
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(
                    new String[]{"android.permission.POST_NOTIFICATIONS"},
                    REQ_NOTIF_PERM);
            }
        }

        // ── Create notification channel + schedule daily reminder ────────────
        // Wrapped in try/catch — notification setup must never crash the app
        try {
            ReminderReceiver.createChannelIfNeeded(this);
            ReminderScheduler.schedule(this);
        } catch (Exception ignored) {}

        // ── WebView ──────────────────────────────────────────────────────────
        webView = new WebView(this);
        setupWebView();
        setContentView(webView);

        // ── Handle widget "＋ Log" tap — deep-link to log tab ────────────────
        String action = getIntent().getStringExtra("action");
        if ("log".equals(action)) {
            // Load app then switch to log tab via JS after page is ready
            webView.loadUrl("file:///android_asset/index.html");
            webView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    // Switch to log tab and focus the weight input
                    view.evaluateJavascript(
                        "document.querySelector('[onclick*=\"log\"]') && " +
                        "switchTab('log', document.querySelector('[onclick*=\\'log\\']'));" +
                        "setTimeout(function(){var w=document.getElementById('weightInput');if(w)w.focus();},300);",
                        null);
                    // Reset to normal client after first load
                    view.setWebViewClient(new WebViewClient() {
                        @Override public boolean shouldOverrideUrlLoading(WebView v, String url) { return false; }
                    });
                }
            });
        } else {
            webView.loadUrl("file:///android_asset/index.html");
        }
    }

    // ── WebView setup ─────────────────────────────────────────────────────────
    private void setupWebView() {
        webView.setBackgroundColor(Color.parseColor("#050508"));
        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        if (Build.VERSION.SDK_INT >= 21)
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);

        webView.addJavascriptInterface(new AppBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, String url) { return false; }
        });

        // WebChromeClient handles ONLY the import file picker
        // (triggered by the hidden #importFileInput in HTML)
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView wv,
                    ValueCallback<Uri[]> cb, FileChooserParams params) {
                // Cancel any stale callback
                if (importFileCallback != null) {
                    importFileCallback.onReceiveValue(null);
                    importFileCallback = null;
                }
                importFileCallback = cb;

                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                    "text/csv", "text/comma-separated-values", "text/plain",
                    "application/csv", "application/vnd.ms-excel",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                });
                intent.putExtra(Intent.EXTRA_TITLE, "Select CSV or Excel file");
                try {
                    startActivityForResult(
                        Intent.createChooser(intent, "Import weight data"),
                        REQ_IMPORT_FILE);
                } catch (Exception e) {
                    importFileCallback.onReceiveValue(null);
                    importFileCallback = null;
                    return false;
                }
                return true;
            }
        });
    }

    // ── JavaScript Bridge ─────────────────────────────────────────────────────
    public class AppBridge {

        /** Save the CSV export to Downloads */
        @JavascriptInterface
        public void saveExcelFile(String data, String fileName) {
            pendingData     = data;
            pendingFileName = fileName;
            pendingMime     = "text/csv";
            runOnUiThread(new Runnable() { public void run() { triggerSave(); } });
        }

        /** Save the JSON backup to Downloads — uses text/plain for max compatibility */
        @JavascriptInterface
        public void saveJsonFile(String data, String fileName) {
            pendingData     = data;
            pendingFileName = fileName;
            pendingMime     = "text/plain"; // IMPORTANT: application/json rejected on some devices
            runOnUiThread(new Runnable() { public void run() { triggerSave(); } });
        }

        /**
         * Opens a SEPARATE native file picker for JSON restore.
         * Uses REQ_RESTORE_FILE — completely independent of the import picker.
         * This is intentionally NOT using WebChromeClient so there's zero interference.
         */
        @JavascriptInterface
        public void openRestorePicker() {
            runOnUiThread(new Runnable() {
                public void run() {
                    Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("*/*");
                    // Accept JSON and plain text (some file managers label .json as text/plain)
                    intent.putExtra(Intent.EXTRA_MIME_TYPES,
                        new String[]{"application/json", "text/plain", "*/*"});
                    intent.putExtra(Intent.EXTRA_TITLE, "Select backup .json file");
                    try {
                        startActivityForResult(
                            Intent.createChooser(intent, "Choose backup file"),
                            REQ_RESTORE_FILE);
                    } catch (Exception e) {
                        webView.evaluateJavascript(
                            "onRestoreError('Could not open file picker')", null);
                    }
                }
            });
        }

        /**
         * Called by JS on every lsSet() — mirrors localStorage into SharedPreferences
         * so the widget and notification system can read weight data without a WebView.
         * Also triggers a widget refresh whenever data changes.
         */
        @JavascriptInterface
        public void syncData(String key, String value) {
            SharedDataHelper.getPrefs(getApplicationContext())
                .edit().putString(key, value).apply();
            // Refresh all home-screen widgets with new data
            WeightWidgetProvider.notifyDataChanged(getApplicationContext());
            // If today's weight was just logged, cancel any pending notification
            if ("wt_entries".equals(key) && SharedDataHelper.isLoggedToday(getApplicationContext())) {
                android.app.NotificationManager nm =
                    (android.app.NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                if (nm != null) nm.cancel(ReminderReceiver.NOTIFICATION_ID);
            }
        }

        /**
         * Called by JS to enable/disable or reschedule the daily reminder.
         * hour and minute are 24-hour format.
         */
        @JavascriptInterface
        public void setReminder(final boolean enabled, final int hour, final int minute) {
            runOnUiThread(new Runnable() {
                public void run() {
                    if (enabled) ReminderScheduler.scheduleAt(getApplicationContext(), hour, minute);
                    else         ReminderScheduler.cancel(getApplicationContext());
                }
            });
        }

        /**
         * Called by JS to get current reminder state.
         * Returns JSON: {"enabled":true,"hour":20,"minute":0}
         */
        @JavascriptInterface
        public String getReminderState() {
            boolean en  = ReminderScheduler.isEnabled(getApplicationContext());
            int hour    = ReminderScheduler.getSavedHour(getApplicationContext());
            int minute  = ReminderScheduler.getSavedMinute(getApplicationContext());
            return "{\"enabled\":" + en + ",\"hour\":" + hour + ",\"minute\":" + minute + "}";
        }
    }

    // ── Save file to Downloads ────────────────────────────────────────────────
    private void triggerSave() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            doSaveFile(pendingData, pendingFileName, pendingMime);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                REQ_STORAGE_PERM);
        } else {
            doSaveFile(pendingData, pendingFileName, pendingMime);
        }
    }

    private void doSaveFile(final String data, final String fileName, final String mimeType) {
        new Thread(new Runnable() { public void run() {
            try {
                OutputStream out;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                    cv.put(MediaStore.Downloads.MIME_TYPE, mimeType);
                    cv.put(MediaStore.Downloads.IS_PENDING, 1);
                    Uri col = MediaStore.Downloads.getContentUri(
                        MediaStore.VOLUME_EXTERNAL_PRIMARY);
                    Uri itemUri = getContentResolver().insert(col, cv);
                    out = getContentResolver().openOutputStream(itemUri);
                    out.write(data.getBytes("UTF-8"));
                    out.close();
                    cv.clear();
                    cv.put(MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(itemUri, cv, null, null);
                } else {
                    File dir = Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS);
                    dir.mkdirs();
                    out = new FileOutputStream(new File(dir, fileName));
                    out.write(data.getBytes("UTF-8"));
                    out.close();
                }
                final String fn = fileName;
                runOnUiThread(new Runnable() { public void run() {
                    webView.evaluateJavascript(
                        "onExportSuccess('" + fn.replace("'", "\\'") + "')", null);
                }});
            } catch (Exception e) {
                final String err = e.getMessage() != null
                    ? e.getMessage().replace("'", "") : "unknown error";
                runOnUiThread(new Runnable() { public void run() {
                    webView.evaluateJavascript("onExportFailed('" + err + "')", null);
                }});
            }
        }}).start();
    }

    // ── File picker results ───────────────────────────────────────────────────
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_IMPORT_FILE) {
            // CSV/XLSX import — must always resolve the WebChromeClient callback
            if (importFileCallback == null) return;
            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
                Uri uri = data.getData();
                results = new Uri[]{uri};
                readFileForImport(uri); // read and send to JS
            }
            importFileCallback.onReceiveValue(results);
            importFileCallback = null;

        } else if (requestCode == REQ_RESTORE_FILE) {
            // JSON restore — completely separate from import
            if (resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
                readFileForRestore(data.getData());
            }
            // No callback to resolve here — this was a direct Intent
        }
    }

    // ── Read CSV/XLSX for import ──────────────────────────────────────────────
    private void readFileForImport(final Uri uri) {
        new Thread(new Runnable() { public void run() {
            try {
                String fileName = getFileName(uri);
                String ext = getExt(fileName);
                byte[] bytes = readBytes(uri, 5 * 1024 * 1024);
                if (bytes == null) { sendError(false, "File too large (max 5MB)"); return; }

                if ("xlsx".equals(ext) || "xls".equals(ext)) {
                    final String b64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP);
                    final String name = fileName.replace("'", "\\'");
                    runOnUiThread(new Runnable() { public void run() {
                        webView.evaluateJavascript(
                            "receiveXLSXData('" + name + "','" + b64 + "')", null);
                    }});
                } else {
                    // CSV / TXT
                    String text = new String(bytes, "UTF-8");
                    text = text.replace("\\", "\\\\").replace("`", "\\`").replace("$", "\\$");
                    final String safeText = text;
                    final String name = fileName.replace("'", "\\'");
                    runOnUiThread(new Runnable() { public void run() {
                        webView.evaluateJavascript(
                            "receiveCSVData('" + name + "', `" + safeText + "`)", null);
                    }});
                }
            } catch (Exception e) {
                sendError(false, e.getMessage() != null ? e.getMessage() : "read error");
            }
        }}).start();
    }

    // ── Read JSON for restore ─────────────────────────────────────────────────
    private void readFileForRestore(final Uri uri) {
        new Thread(new Runnable() { public void run() {
            try {
                byte[] bytes = readBytes(uri, 10 * 1024 * 1024);
                if (bytes == null) { sendError(true, "Backup file too large"); return; }

                final String json = new String(bytes, "UTF-8").trim();

                // Basic sanity check — must look like JSON
                if (!json.startsWith("{")) {
                    sendError(true, "Not a valid backup file — expected JSON");
                    return;
                }

                // Pass raw JSON to JS — receiveRestoreData() will parse it
                runOnUiThread(new Runnable() { public void run() {
                    webView.evaluateJavascript("receiveRestoreData(" + json + ")", null);
                }});
            } catch (Exception e) {
                sendError(true, e.getMessage() != null ? e.getMessage() : "read error");
            }
        }}).start();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private byte[] readBytes(Uri uri, long maxBytes) throws Exception {
        InputStream is = getContentResolver().openInputStream(uri);
        if (is == null) throw new Exception("Cannot open file");
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n; long total = 0;
        while ((n = is.read(buf)) != -1) {
            baos.write(buf, 0, n);
            total += n;
            if (total > maxBytes) { is.close(); return null; }
        }
        is.close();
        return baos.toByteArray();
    }

    private String getFileName(Uri uri) {
        String name = "file";
        try {
            android.database.Cursor c = getContentResolver().query(uri, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (i >= 0) name = c.getString(i);
                c.close();
            }
        } catch (Exception e) {
            String p = uri.getPath();
            if (p != null) name = p.substring(p.lastIndexOf('/') + 1);
        }
        return name;
    }

    private String getExt(String name) {
        int dot = name.lastIndexOf('.');
        return dot >= 0 ? name.substring(dot + 1).toLowerCase().trim() : "";
    }

    private void sendError(final boolean isRestore, final String msg) {
        final String safe = msg.replace("'", "\\'").replace("\n", " ");
        runOnUiThread(new Runnable() { public void run() {
            if (isRestore)
                webView.evaluateJavascript("onRestoreError('" + safe + "')", null);
            else
                webView.evaluateJavascript("showImportError('" + safe + "')", null);
        }});
    }

    // ── Permission result ─────────────────────────────────────────────────────
    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] grants) {
        super.onRequestPermissionsResult(req, perms, grants);
        if (req == REQ_STORAGE_PERM
                && grants.length > 0
                && grants[0] == PackageManager.PERMISSION_GRANTED
                && pendingData != null) {
            doSaveFile(pendingData, pendingFileName, pendingMime);
            pendingData = null; pendingFileName = null; pendingMime = null;
        }
        if (req == REQ_NOTIF_PERM) {
            // Schedule reminder regardless of grant result — ReminderScheduler
            // handles the exact-alarm permission check internally and never throws.
            try {
                ReminderScheduler.schedule(getApplicationContext());
            } catch (Exception ignored) {
                // Silently ignore — app must not crash due to notification setup
            }
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    /**
     * Called when the app is already running and receives a new Intent —
     * e.g. user taps the widget "＋ Log" button while the app is open.
     * launchMode="singleTask" ensures this fires instead of creating a new Activity.
     */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if ("log".equals(intent.getStringExtra("action"))) {
            // App already loaded — just switch tab via JS
            if (webView != null) {
                webView.evaluateJavascript(
                    "switchTab('log', document.querySelector('[onclick*=\\'log\\']'));" +
                    "setTimeout(function(){var w=document.getElementById('weightInput');if(w)w.focus();},200);",
                    null);
            }
        }
    }

    @Override protected void onPause()  {
        super.onPause();
        webView.onPause();
        if (syncReceiver != null) {
            try { unregisterReceiver(syncReceiver); } catch (Exception ignored) {}
            syncReceiver = null;
        }
    }

    @Override protected void onResume() {
        super.onResume();
        webView.onResume();
        // Register receiver to listen for widget's sync request
        syncReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                // Widget is asking for fresh data — push all localStorage to SharedPreferences
                if (webView != null) {
                    webView.evaluateJavascript(
                        "(function(){" +
                        "  var keys=['wt_entries','wt_profile','wt_measurements'," +
                        "            'wt_nutrition','wt_nutrition_goals','wt_milestones'];" +
                        "  keys.forEach(function(k){" +
                        "    var v=localStorage.getItem(k);" +
                        "    if(v&&typeof AndroidBridge!=='undefined') AndroidBridge.syncData(k,v);" +
                        "  });" +
                        "})()", null);
                }
            }
        };
        IntentFilter filter = new IntentFilter(WeightWidgetProvider.ACTION_REQUEST_SYNC);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(syncReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(syncReceiver, filter);
        }
    }
}
