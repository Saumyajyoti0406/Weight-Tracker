package com.saumyajyoti.weighttracker;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import java.util.Calendar;

public class ReminderScheduler {

    private static final String PREFS       = "wt_reminder_prefs";
    private static final String KEY_ENABLED = "reminder_enabled";
    private static final String KEY_HOUR    = "reminder_hour";
    private static final String KEY_MINUTE  = "reminder_minute";

    private static final int DEFAULT_HOUR   = 20;
    private static final int DEFAULT_MINUTE = 0;

    /** Schedule daily reminder at saved time (or 8:00 PM default). */
    public static void schedule(Context ctx) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (!prefs.getBoolean(KEY_ENABLED, true)) return;
        scheduleAt(ctx,
            prefs.getInt(KEY_HOUR,   DEFAULT_HOUR),
            prefs.getInt(KEY_MINUTE, DEFAULT_MINUTE));
    }

    /** Schedule at a specific hour:minute (24h). Saves preference. */
    public static void scheduleAt(Context ctx, int hour, int minute) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_ENABLED, true)
            .putInt(KEY_HOUR,   hour)
            .putInt(KEY_MINUTE, minute)
            .apply();

        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        long triggerAt = nextOccurrence(hour, minute);
        PendingIntent pi = buildPendingIntent(ctx);

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                // Android 12+ — only use exact alarm if user granted permission
                // (Settings → Special app access → Alarms & reminders).
                // If not granted, fall back to inexact window alarm — still reliable
                // for a daily reminder within a ~15 min window.
                if (am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
                } else {
                    // Inexact but battery-friendly — fires within 15 min of target
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
                }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                // Android 6–11 — exact is fine, no special permission needed
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            } else {
                // Android 5 — use repeating (simpler, no exact needed)
                am.setRepeating(AlarmManager.RTC_WAKEUP, triggerAt,
                    AlarmManager.INTERVAL_DAY, pi);
            }
        } catch (SecurityException e) {
            // Should never hit here after the canScheduleExactAlarms() check,
            // but guard anyway so the app never crashes.
            try {
                am.set(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            } catch (Exception ignored) {}
        }
    }

    /** Schedule for tomorrow at the same time. Called from ReminderReceiver. */
    public static void rescheduleNextDay(Context ctx) {
        if (!isEnabled(ctx)) return;
        int hour   = getSavedHour(ctx);
        int minute = getSavedMinute(ctx);

        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;

        // Always tomorrow — add 1 day to avoid firing again today
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, hour);
        cal.set(Calendar.MINUTE,      minute);
        cal.set(Calendar.SECOND,      0);
        cal.set(Calendar.MILLISECOND, 0);
        cal.add(Calendar.DAY_OF_YEAR, 1);
        long triggerAt = cal.getTimeInMillis();

        PendingIntent pi = buildPendingIntent(ctx);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            } else {
                am.set(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            }
        } catch (SecurityException ignored) {}
    }

    /** Cancel the reminder entirely. */
    public static void cancel(Context ctx) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_ENABLED, false)
            .apply();
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(buildPendingIntent(ctx));
    }

    public static boolean isEnabled(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_ENABLED, true);
    }

    public static int getSavedHour(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getInt(KEY_HOUR, DEFAULT_HOUR);
    }

    public static int getSavedMinute(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getInt(KEY_MINUTE, DEFAULT_MINUTE);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    /** Returns the next occurrence of hour:minute — today if still in future, else tomorrow. */
    private static long nextOccurrence(int hour, int minute) {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, hour);
        cal.set(Calendar.MINUTE,      minute);
        cal.set(Calendar.SECOND,      0);
        cal.set(Calendar.MILLISECOND, 0);
        if (cal.getTimeInMillis() <= System.currentTimeMillis()) {
            cal.add(Calendar.DAY_OF_YEAR, 1);
        }
        return cal.getTimeInMillis();
    }

    private static PendingIntent buildPendingIntent(Context ctx) {
        Intent intent = new Intent(ctx, ReminderReceiver.class);
        intent.setAction(ReminderReceiver.ACTION_REMINDER);
        int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
            ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            : PendingIntent.FLAG_UPDATE_CURRENT;
        return PendingIntent.getBroadcast(ctx, 0, intent, flags);
    }
}
