package com.saumyajyoti.weighttracker;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Reads weight tracker data.
 *
 * Priority:
 *  1. SharedPreferences ("wt_shared") — written by AndroidBridge.syncData() whenever the app is open
 *  2. WebView localStorage SQLite DB  — fallback so widget works even if app was never opened
 *     after install / update
 */
public class SharedDataHelper {

    public static final String PREFS_NAME = "wt_shared";

    public static SharedPreferences getPrefs(Context ctx) {
        return ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    /** Today's date as YYYY-MM-DD */
    public static String todayStr() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
    }

    // ── Core data readers ────────────────────────────────────────────────────

    public static JSONArray getEntries(Context ctx) {
        return getJsonArray(ctx, "wt_entries");
    }

    public static JSONObject getProfile(Context ctx) {
        try {
            String raw = getValue(ctx, "wt_profile");
            if (raw != null && !raw.isEmpty()) return new JSONObject(raw);
        } catch (Exception ignored) {}
        return new JSONObject();
    }

    public static float getLatestWeight(Context ctx) {
        try {
            JSONArray entries = getEntries(ctx);
            if (entries.length() == 0) return -1f;
            JSONObject last = entries.getJSONObject(entries.length() - 1);
            return (float) last.getDouble("weight");
        } catch (Exception e) { return -1f; }
    }

    public static float getPreviousWeight(Context ctx) {
        try {
            JSONArray entries = getEntries(ctx);
            if (entries.length() < 2) return -1f;
            JSONObject prev = entries.getJSONObject(entries.length() - 2);
            return (float) prev.getDouble("weight");
        } catch (Exception e) { return -1f; }
    }

    public static boolean isLoggedToday(Context ctx) {
        try {
            String today = todayStr();
            JSONArray entries = getEntries(ctx);
            for (int i = entries.length() - 1; i >= 0; i--) {
                if (today.equals(entries.getJSONObject(i).getString("date"))) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    public static int getStreak(Context ctx) {
        try {
            JSONArray entries = getEntries(ctx);
            if (entries.length() == 0) return 0;
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            long DAY_MS = 86400000L;
            long today = sdf.parse(todayStr()).getTime();
            int streak = 0;
            long expect = today;
            for (int i = entries.length() - 1; i >= 0; i--) {
                String dateStr = entries.getJSONObject(i).getString("date");
                long entryTime = sdf.parse(dateStr).getTime();
                if (entryTime == expect) { streak++; expect -= DAY_MS; }
                else if (entryTime < expect) break;
            }
            return streak;
        } catch (Exception e) { return 0; }
    }

    public static float getGoal(Context ctx) {
        try {
            JSONObject profile = getProfile(ctx);
            if (profile.has("goal") && profile.getDouble("goal") > 0)
                return (float) profile.getDouble("goal");
        } catch (Exception ignored) {}
        return -1f;
    }

    public static String getUserName(Context ctx) {
        try {
            String name = getProfile(ctx).optString("name", "");
            return name.isEmpty() ? "User" : name;
        } catch (Exception e) { return "User"; }
    }

    public static float getGoalProgress(Context ctx) {
        try {
            float goal = getGoal(ctx);
            if (goal < 0) return -1f;
            JSONArray entries = getEntries(ctx);
            if (entries.length() == 0) return -1f;
            float start = (float) entries.getJSONObject(0).getDouble("weight");
            float current = getLatestWeight(ctx);
            if (start == goal) return 1f;
            return Math.max(0f, Math.min(1f, (start - current) / (start - goal)));
        } catch (Exception e) { return -1f; }
    }

    /** Current theme name e.g. "neon", "ocean", "galaxy". Defaults to "neon". */
    public static String getTheme(Context ctx) {
        try {
            String raw = getValue(ctx, "wt_theme");
            if (raw == null || raw.isEmpty() || raw.equals("null")) return "neon";
            // localStorage stores as JSON string with quotes e.g. "\"neon\""
            return raw.replace("\"", "").trim();
        } catch (Exception e) { return "neon"; }
    }

    // ── Value retrieval with WebView localStorage fallback ───────────────────

    /**
     * Get a localStorage value by key.
     * First checks SharedPreferences (written by syncData when app is open).
     * Falls back to reading WebView's localStorage SQLite database directly.
     */
    public static String getValue(Context ctx, String key) {
        // 1. SharedPreferences — fastest, most reliable
        String fromPrefs = getPrefs(ctx).getString(key, null);
        if (fromPrefs != null && !fromPrefs.equals("null") && !fromPrefs.isEmpty()) {
            return fromPrefs;
        }

        // 2. WebView localStorage database — fallback
        return readFromWebViewLocalStorage(ctx, key);
    }

    private static JSONArray getJsonArray(Context ctx, String key) {
        try {
            String raw = getValue(ctx, key);
            if (raw != null && raw.startsWith("[")) return new JSONArray(raw);
        } catch (Exception ignored) {}
        return new JSONArray();
    }

    /**
     * Reads directly from WebView's localStorage SQLite file.
     * WebView stores localStorage at:
     *   app_data_dir/app_webview/Default/Local Storage/leveldb/  (newer Chrome-based WebView)
     *   app_data_dir/app_webview/Local Storage/file__0.localstorage  (older)
     *
     * The leveldb format is not easily readable, but the .localstorage file is SQLite.
     * We try the SQLite path — this works on most Android versions with the system WebView.
     */
    private static String readFromWebViewLocalStorage(Context ctx, String key) {
        // Common paths for WebView localStorage SQLite file
        String dataDir = ctx.getApplicationInfo().dataDir;
        String[] candidatePaths = {
            dataDir + "/app_webview/Local Storage/file__0.localstorage",
            dataDir + "/app_webview/Default/Local Storage/file__0.localstorage",
            dataDir + "/webview/Local Storage/file__0.localstorage",
        };

        for (String path : candidatePaths) {
            File f = new File(path);
            if (!f.exists()) continue;
            try {
                String result = queryLocalStorageDb(f.getAbsolutePath(), key);
                if (result != null) {
                    // Cache it in SharedPreferences for next time
                    getPrefs(ctx).edit().putString(key, result).apply();
                    return result;
                }
            } catch (Exception ignored) {}
        }
        return null;
    }

    private static String queryLocalStorageDb(String dbPath, String key) {
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = SQLiteDatabase.openDatabase(dbPath, null,
                SQLiteDatabase.OPEN_READONLY | SQLiteDatabase.NO_LOCALIZED_COLLATORS);

            // Table is "ItemTable" with columns "key" (TEXT) and "value" (BLOB/TEXT)
            cursor = db.rawQuery(
                "SELECT value FROM ItemTable WHERE key = ?",
                new String[]{ key });

            if (cursor != null && cursor.moveToFirst()) {
                // Value is stored as UTF-16 bytes in BLOB — convert properly
                byte[] blob = cursor.getBlob(0);
                if (blob != null && blob.length > 0) {
                    // WebView stores as UTF-16 LE with BOM
                    String val = new String(blob, "UTF-16LE").trim();
                    if (val.startsWith("\uFEFF")) val = val.substring(1);
                    return val;
                }
                // Some versions store as plain text
                String text = cursor.getString(0);
                if (text != null && !text.isEmpty()) return text;
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) try { cursor.close(); } catch (Exception ignored) {}
            if (db != null) try { db.close(); } catch (Exception ignored) {}
        }
        return null;
    }
}
