package com.saumyajyoti.weighttracker;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class ReminderReceiver extends BroadcastReceiver {

    public static final String CHANNEL_ID      = "wt_daily_reminder";
    public static final int    NOTIFICATION_ID  = 1001;
    public static final String ACTION_REMINDER  = "com.saumyajyoti.weighttracker.DAILY_REMINDER";
    public static final String ACTION_BOOT      = "android.intent.action.BOOT_COMPLETED";

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();

        if (ACTION_BOOT.equals(action)) {
            // Re-schedule after reboot
            ReminderScheduler.schedule(context);
            return;
        }

        // Daily reminder alarm fired — reschedule for tomorrow first
        ReminderScheduler.rescheduleNextDay(context);

        // Then check if already logged today — if so, stay silent
        if (SharedDataHelper.isLoggedToday(context)) return;

        createChannelIfNeeded(context);
        showNotification(context);
    }

    public static void createChannelIfNeeded(Context ctx) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                ctx.getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_DEFAULT
            );
            channel.setDescription(ctx.getString(R.string.notification_channel_desc));
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{0, 250, 100, 250});
            channel.enableLights(true);
            channel.setLightColor(0xFF00FFE0); // cyan

            NotificationManager nm = ctx.getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private void showNotification(Context ctx) {
        // Tap → open app
        Intent openApp = new Intent(ctx, MainActivity.class);
        openApp.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
            ? PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            : PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent pi = PendingIntent.getActivity(ctx, 0, openApp, flags);

        int streak = SharedDataHelper.getStreak(ctx);
        String body = streak > 0
            ? "You're on a " + streak + "-day streak — don't break it!"
            : ctx.getString(R.string.notif_body);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(ctx.getString(R.string.notif_title))
            .setContentText(body)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setColor(0xFF00FFE0)
            .setVibrate(new long[]{0, 250, 100, 250});

        try {
            NotificationManagerCompat.from(ctx).notify(NOTIFICATION_ID, builder.build());
        } catch (SecurityException e) {
            // POST_NOTIFICATIONS permission not granted — silently ignore
        }
    }
}
