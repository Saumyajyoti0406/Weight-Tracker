@echo off
echo ============================================
echo  Weight Tracker APK Builder
echo ============================================
echo.

REM Check JAVA_HOME
if "%JAVA_HOME%"=="" (
    echo ERROR: JAVA_HOME not set.
    echo Please install JDK 17 and set JAVA_HOME.
    pause
    exit /b 1
)

REM Build release APK (signed with fixed keystore - upgrades without uninstall)
echo Building release APK...
call gradlew.bat assembleRelease

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo BUILD FAILED. Check errors above.
    pause
    exit /b 1
)

echo.
echo ============================================
echo  BUILD SUCCESS
echo ============================================
echo.
echo APK location:
echo   app\build\outputs\apk\release\app-release.apk
echo.
echo This APK is signed with a FIXED key (weighttracker.keystore)
echo so future versions can be installed WITHOUT uninstalling first.
echo.
echo IMPORTANT: Keep weighttracker.keystore safe - you need it
echo for all future builds or users will have to reinstall.
echo.
pause
